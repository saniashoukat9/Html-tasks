//js string Destructuring
let str = "Hi";
let [a, b] = str;
console.log(a); 
console.log(b); 

//  js array Destructuring
let colors = ["red", "green", "blue"];
let [first, second, third] = colors;
console.log(first);  
console.log(second); 
console.log(third);  

// js object Destructuring
let person = { name: "Sania", age: 20 };
let { name, age } = person;
console.log(name);
console.log(age); 