//importing data from user.js by using *.

import * as usr from './modules/user.js';
console.log(usr.Name);
console.log(usr.age)
usr.sania();

//importing data from account.js by using ,.

import { withdraw } from './modules/account.js';
withdraw();