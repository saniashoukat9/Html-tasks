let account_no = 568;
let account_type = "saving";

export function withdraw(){
    console.log("function withdraw successfully!");
    
}
function deposit(){
    console.log("balance updated successfully!");
    
}