export let Name = "saniashkt";
export let age = 24;

export function sania(){
    console.log("hello sania");
    
}
 function Ifrah(){
    console.log("hello ifrah");
    
}