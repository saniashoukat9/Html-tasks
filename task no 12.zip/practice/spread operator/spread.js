// example 1 of spread operator.
let array1 = [ 1,2,3];
let array2 = [ 4,5,6,...array1];

console.log(array2);

// example 2 of spread operator.
let array3 = [ 1,2,3];
let array4 = [...array3, 4,5,6,];

console.log(array4);

// example 3 for spreading data.
let username = "coding javascript";
let letters = [ ...username];
console.log(letters)









